import { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ProductDetailPage from './pages/ProductDetailPage';
import SearchPage from './pages/SearchPage';
import AdminPage from './pages/AdminPage';
import ProductCard from './components/ProductCard';
import CartPage from './pages/CartPage';
import { products as initialProducts } from './data/products';
import type { Product } from './data/products';

type Route =
  | { type: 'home' }
  | { type: 'product'; id: string }
  | { type: 'search'; query: string; category?: string }
  | { type: 'category'; category: string }
  | { type: 'new-arrivals' }
  | { type: 'cart' }
  | { type: 'admin' };

let nextId = initialProducts.length + 1;

export default function App() {
  const [route, setRoute] = useState<Route>({ type: 'home' });
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [cart, setCart] = useState<string[]>([]);
  const [cartToast, setCartToast] = useState<string | null>(null);
  const [adminPin, setAdminPin] = useState('');
  const [showAdminGate, setShowAdminGate] = useState(false);
  const [adminPinError, setAdminPinError] = useState(false);

  useEffect(() => {
    if (route.type !== 'admin') window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [route]);

  function navigate(page: string) {
    if (page === 'home') setRoute({ type: 'home' });
    else if (page === 'cart') setRoute({ type: 'cart' });
    else if (page === 'new-arrivals') setRoute({ type: 'new-arrivals' });
    else if (page === 'admin') {
      setAdminPin('');
      setAdminPinError(false);
      setShowAdminGate(true);
    } else if (['on-hand', 'pre-order', 'new-release'].includes(page)) {
      setRoute({ type: 'category', category: page });
    } else {
      setRoute({ type: 'home' });
    }
  }

  function handleAdminPin() {
    if (adminPin === '1234') {
      setShowAdminGate(false);
      setRoute({ type: 'admin' });
    } else {
      setAdminPinError(true);
      setTimeout(() => setAdminPinError(false), 1500);
    }
  }

  function viewProduct(id: string) {
    setRoute({ type: 'product', id });
  }

  function handleSearch(query: string, category?: string) {
    setRoute({ type: 'search', query, category });
  }

  function removeFromCart(id: string) {
    setCart((prev) => {
      const idx = prev.lastIndexOf(id);
      if (idx === -1) return prev;
      return [...prev.slice(0, idx), ...prev.slice(idx + 1)];
    });
  }

  function clearCart() {
    setCart([]);
  }

  function addToCart(id: string) {
    setCart((prev) => [...prev, id]);
    const p = products.find((x) => x.id === id);
    setCartToast(p?.name ?? 'Item');
    setTimeout(() => setCartToast(null), 3000);
  }

  function handleAddProduct(data: Omit<Product, 'id'>) {
    const id = `p${String(nextId++).padStart(3, '0')}`;
    setProducts((prev) => [{ id, ...data }, ...prev]);
  }

  function handleEditProduct(updated: Product) {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
  }

  function handleDeleteProduct(id: string) {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  }

  const sortedNew = [...products].sort((a, b) => new Date(b.dateAdded).getTime() - new Date(a.dateAdded).getTime());

  if (route.type === 'admin') {
    return (
      <AdminPage
        products={products}
        onAdd={handleAddProduct}
        onEdit={handleEditProduct}
        onDelete={handleDeleteProduct}
        onNavigate={(page) => {
          if (page === 'home') setRoute({ type: 'home' });
          else navigate(page);
        }}
      />
    );
  }

  return (
    <div style={{ backgroundColor: '#0A0A0B', minHeight: '100vh' }}>
      <Header onSearch={(q) => handleSearch(q)} onNavigate={navigate} cartCount={cart.length} />

      <main style={{ paddingBottom: 16 }}>
        {route.type === 'home' && (
          <HomePage products={products} onView={viewProduct} onNavigate={navigate} onAddToCart={addToCart} />
        )}
        {route.type === 'product' && (
          <ProductDetailPage
            productId={route.id}
            onNavigate={navigate}
            onView={viewProduct}
            onAddToCart={addToCart}
            products={products}
          />
        )}
        {route.type === 'search' && (
          <SearchPage
            initialQuery={route.query}
            initialCategory={route.category}
            onView={viewProduct}
            onAddToCart={addToCart}
            onSearch={handleSearch}
            products={products}
          />
        )}
        {route.type === 'category' && (
          <SearchPage
            initialQuery=""
            initialCategory={route.category}
            onView={viewProduct}
            onAddToCart={addToCart}
            onSearch={handleSearch}
            products={products}
          />
        )}
        {route.type === 'new-arrivals' && (
          <div className="max-w-7xl mx-auto px-4 py-8">
            <div className="mb-8">
              <p style={{ color: '#22C55E', fontFamily: 'Outfit, sans-serif', fontSize: 11 }} className="font-700 uppercase tracking-widest mb-1">Just Added</p>
              <h1 style={{ fontFamily: 'Outfit, sans-serif', color: '#F0F0F4' }} className="text-3xl font-800">New Arrivals</h1>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-3">
              {sortedNew.map((p) => (
                <ProductCard key={p.id} product={p} onView={viewProduct} onAddToCart={addToCart} size="sm" />
              ))}
            </div>
          </div>
        )}
        {route.type === 'cart' && (
          <CartPage
            cart={cart}
            products={products}
            onNavigate={navigate}
            onRemoveFromCart={removeFromCart}
            onClearCart={clearCart}
          />
        )}
      </main>

      <Footer onAdminClick={() => navigate('admin')} />

      {/* Cart toast */}
      {cartToast && (
        <div
          style={{
            backgroundColor: '#141418',
            border: '1px solid rgba(34,197,94,0.25)',
            borderLeft: '3px solid #22C55E',
            fontFamily: 'Inter, sans-serif',
            boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
            position: 'fixed',
            bottom: 80,
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 50,
            padding: '12px 16px',
            borderRadius: '0.75rem',
            width: 'calc(100% - 32px)',
            maxWidth: 320,
            display: 'flex',
            alignItems: 'center',
            gap: 10,
          }}
        >
          <span style={{ color: '#22C55E', flexShrink: 0 }}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.25" />
              <path d="M5 8L7 10L11 6" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          <span style={{ color: '#B0B0BC', fontSize: 13 }}>
            <span style={{ color: '#F0F0F4', fontWeight: 600 }}>{cartToast}</span> added to cart
          </span>
        </div>
      )}

      {/* Admin PIN gate */}
      {showAdminGate && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center px-4"
          style={{ backgroundColor: 'rgba(0,0,0,0.88)' }}
          onClick={() => setShowAdminGate(false)}
        >
          <div
            style={{
              backgroundColor: '#111114',
              border: adminPinError ? '1px solid rgba(255,45,120,0.4)' : '1px solid #222228',
              borderRadius: '1rem',
              padding: '28px 24px',
              width: '100%',
              maxWidth: 340,
              transition: 'border-color 0.2s',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16, color: '#FF2D78' }}>
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                <rect x="4" y="12" width="20" height="13" rx="2" stroke="currentColor" strokeWidth="1.5" />
                <path d="M9 12V8.5C9 5.46 11.46 3 14.5 3C17.54 3 20 5.46 20 8.5V12" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                <circle cx="14.5" cy="18.5" r="2" fill="currentColor" />
              </svg>
            </div>
            <p style={{ fontFamily: 'Outfit, sans-serif', color: '#F0F0F4', fontSize: 17, textAlign: 'center', marginBottom: 4 }} className="font-700">Admin Access</p>
            <p style={{ fontFamily: 'Inter, sans-serif', color: '#50505C', fontSize: 12, textAlign: 'center', marginBottom: 20 }}>Enter your PIN to continue</p>
            <input
              type="password"
              value={adminPin}
              onChange={(e) => { setAdminPin(e.target.value); setAdminPinError(false); }}
              onKeyDown={(e) => e.key === 'Enter' && handleAdminPin()}
              placeholder="••••"
              autoFocus
              style={{
                backgroundColor: '#0A0A0B',
                border: adminPinError ? '1px solid #FF2D78' : '1px solid #222228',
                color: '#F0F0F4',
                fontFamily: 'Outfit, sans-serif',
                borderRadius: '0.5rem',
                fontSize: 20,
                outline: 'none',
                width: '100%',
                padding: '10px 16px',
                textAlign: 'center',
                letterSpacing: 8,
                marginBottom: 4,
                transition: 'border-color 0.2s',
              }}
            />
            {adminPinError && (
              <p style={{ color: '#FF2D78', fontFamily: 'Inter, sans-serif', fontSize: 12, textAlign: 'center', marginBottom: 12 }}>Incorrect PIN</p>
            )}
            <button
              onClick={handleAdminPin}
              style={{
                background: '#FF2D78',
                color: '#fff',
                fontFamily: 'Outfit, sans-serif',
                fontSize: 14,
                borderRadius: 9999,
                padding: '10px',
                width: '100%',
                border: 'none',
                cursor: 'pointer',
                marginTop: adminPinError ? 0 : 12,
                boxShadow: '0 4px 16px rgba(255,45,120,0.3)',
              }}
              className="font-700 hover:opacity-90 transition-opacity"
            >
              Enter
            </button>
            <p style={{ fontFamily: 'Inter, sans-serif', color: '#30303C', fontSize: 11, textAlign: 'center', marginTop: 14 }}>
              Default PIN: <span style={{ color: '#50505C' }}>1234</span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
